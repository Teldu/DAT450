//
//  ViewController.swift
//  CocoaApp#1
//
//  Created by Sean Smith on 7/8/19.
//  Copyright © 2019 Sean Smith. All rights reserved.
//

import Cocoa
import AudioToolbox
import AVFoundation

class ViewController: NSViewController {
    private let operationQueue: OperationQueue = OperationQueue()

    @IBOutlet weak var reverbSlider: NSSliderCell!
    @IBOutlet weak var delaySlider: NSSliderCell!
    
    @IBOutlet weak var reverbButton: NSButton!
    @IBOutlet weak var delayButton: NSButton!
    @IBOutlet var recordButton: NSView!

    var recorder: playerStruct? = nil
    var isPlaying: Bool = false
    
    var reverbStatus: Bool = false
    var delayStatus: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Effects settings
        reverbSlider.isContinuous = true
        reverbSlider.doubleValue = 50
        reverbSlider.minValue = 0
        reverbSlider.maxValue = 100
        delaySlider.isContinuous = true
        delaySlider.doubleValue = 50
        delaySlider.minValue = 0
        delaySlider.maxValue = 100
        
        //start delay and reverb as off
        reverbButton.state = .off
        delayButton.state = .off
        
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    @IBAction func reverbPushed(_ sender: Any) {
        if(reverbStatus == true){
            reverbStatus = false
            self.recorder?.reverbNode.bypass = true
        }
        else{
            reverbStatus = true
            self.recorder?.reverbNode.wetDryMix = reverbSlider.floatValue
            self.recorder?.reverbNode.bypass = false
        }
    }
    
    @IBAction func delayPushed(_ sender: Any) {
        if(delayStatus == true){
            delayStatus = false
            self.recorder?.delayNode.bypass = true
        }
        else{
            delayStatus = true
            self.recorder?.delayNode.wetDryMix = delaySlider.floatValue
            self.recorder?.delayNode.bypass = false
        }
    }
    
    @IBAction func reverbSliding(_ sender: Any) {
        self.recorder?.reverbNode.wetDryMix = reverbSlider.floatValue
    }
    
    @IBAction func delaySliding(_ sender: Any) {
        self.recorder?.delayNode.wetDryMix = delaySlider.floatValue
    }
    @IBAction func recordPush(_ sender: Any) {
        if(isPlaying == false){
            recorder = setupRecord()
            isPlaying = true
        }
        operationQueue.addOperation{
            self.startRecording(player: self.recorder!, dur: 60)
        }
    }
    
}
extension ViewController{

    struct playerStruct{
        var engine: AVAudioEngine = AVAudioEngine()
        var playerNode: AVAudioPlayerNode = AVAudioPlayerNode()
        var mixerNode: AVAudioMixerNode = AVAudioMixerNode()
        var delayNode = AVAudioUnitDelay()
        var reverbNode = AVAudioUnitReverb()
        var duration: UInt32 = 0
        var inputNode: AVAudioInputNode!
        var outputNode: AVAudioOutputNode!
        
        init(engine: AVAudioEngine, playerNode: AVAudioPlayerNode, mixerNode: AVAudioMixerNode, duration: UInt32,
             reverbNode: AVAudioUnitReverb, delayNode: AVAudioUnitDelay){
            self.engine = engine
            self.playerNode = playerNode
            self.reverbNode = reverbNode
            reverbNode.bypass = true
            self.delayNode = delayNode
            delayNode.bypass = true
            self.duration = duration
            self.inputNode = self.engine.inputNode
            self.outputNode = self.engine.outputNode
        }
    }
    
    //Recording Functionality Starts here (attempt to add effects failed)
    func setupRecord() -> playerStruct{
        let recDuration: UInt32 = 60
        let playerInstance = playerStruct(engine: AVAudioEngine(), playerNode: AVAudioPlayerNode(), mixerNode: AVAudioMixerNode(), duration: recDuration,  reverbNode: AVAudioUnitReverb(), delayNode: AVAudioUnitDelay())
        
        //Attach the nodes
        playerInstance.engine.attach(playerInstance.mixerNode)
        playerInstance.engine.attach(playerInstance.delayNode)
        playerInstance.engine.attach(playerInstance.reverbNode)
        
        //Connect the nodes
        playerInstance.engine.connect(playerInstance.inputNode, to: playerInstance.delayNode, format: nil)
        playerInstance.engine.connect(playerInstance.delayNode, to: playerInstance.reverbNode, format: nil)
        playerInstance.engine.connect(playerInstance.reverbNode, to: playerInstance.mixerNode, format: nil)
        
        //playerInstance.engine.connect(playerInstance.inputNode, to: playerInstance.mixerNode, format: nil)
        playerInstance.engine.connect(playerInstance.mixerNode, to: playerInstance.engine.outputNode, format: nil)
        
        playerInstance.delayNode.delayTime = 1.0
        playerInstance.delayNode.feedback = 0
        playerInstance.delayNode.wetDryMix = 0
        playerInstance.reverbNode.wetDryMix = 0
        playerInstance.reverbNode.loadFactoryPreset(AVAudioUnitReverbPreset.mediumChamber)
        
        //Prepare the engine
        playerInstance.engine.prepare()
        
        return playerInstance
    }
    
    func startRecording(player: playerStruct, dur: UInt32){
        //Start the engine
        do{
            try player.engine.start()
            print("Engine started")
            sleep(dur)
            print("Capture complete")
        }catch{
            print("Failed to play back file \(error.localizedDescription)")
        }
    }
}
